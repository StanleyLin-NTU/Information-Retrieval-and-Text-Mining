import nltk 
import ssl
nltk.download("stopwords")